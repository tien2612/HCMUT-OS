#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <semaphore.h>
#include <fcntl.h>
#include <stdbool.h>
#include<sys/stat.h>
#define SHM_KEY 0x1234678
#define SNAME "/s22emname"
struct shared_data{
int counter ;
int writerID ;
};
int main( int argc , char *argv [ ] ) {
	int shmid ;
	struct shared_data *data ;
	sem_t *sem = sem_open(SNAME, O_CREAT, 0644) ;
	shmid = shmget (SHM_KEY, 1000 , 0644 | IPC_CREAT) ;
	if (shmid < 0) {
		perror ("Shared␣memory") ;
		return 1;
	}else {
		printf ("shared␣memory: ␣%d\n" , shmid) ;
	}

	if (sem == SEM_FAILED){
		printf ("Sem␣ f a i l ed \n") ;
		return -1;
	}
	data = ( struct shared_data *)shmat(shmid , 0 ,0) ;
	if (data == ( struct shared_data *)-1) {
	perror ("shmat") ;
	exit (1) ;
	}
	for ( int i=0; i < 20; i++){
		sem_wait(sem) ;
		printf ("Read␣from␣Writer␣ID: ␣%d␣with␣counter : ␣%d\n" ,data->writerID , data->counter ) ;
		data->writerID = 2;
		sem_post(sem) ;
		sleep (1) ;
	}
	if (shmdt(data ) == -1) {
	perror ("shmdt") ;
	return 1;
	}
	sem_close (sem) ;
	return 0;
}
